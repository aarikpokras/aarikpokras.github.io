import os
# os.chdir('bumfuzzleOS')
import start
name=start.name

import cmd
# END


# REMEMBER, to print, use the print command. Duh.
# IFS COPIER SECTION
