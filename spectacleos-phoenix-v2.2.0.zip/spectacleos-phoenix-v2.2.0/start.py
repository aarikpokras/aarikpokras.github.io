from version import ver
# vers=version.ver
print("Welcome to BumfuzzleOS! This is version "+ver+" command line.\n🔔 This is the Alpha version, so it kinda sucks.")
name=input('Enter desired hostname. ==> ')


# Make continous imports of py files to make full command line file - import variables with import <filename>, then to import variables, <new-var-name>=<filename>.<old-var-name>
