# Welcome to SearchMe!
SearchMe was created on January 1, 2021 by Aarik Pokras and James Smith. Open Source on [https://github.com/JamesSmith-dev/SearchMe](https://github.com/JamesSmith-dev/SearchMe).
Go to [CODE_OF_CONDUCT.md](searchme.glitch.me/CODE_OF_CONDUCT.md) for the license.
