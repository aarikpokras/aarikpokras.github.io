console.log("Welcome to SearchMe!");
