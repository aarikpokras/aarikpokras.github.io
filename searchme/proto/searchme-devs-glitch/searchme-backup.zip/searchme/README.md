# Welcome to SearchMe!

SearchMe was created on January 1, 2021 by Aarik Pokras.
Go to [LICENSE.txt](searchme.glitch.me/LICENSE.txt) for the license.